/**
 * Commandes du poste — CÔTÉ SERVEUR : les bascules enregistrées sur le poste, et l'exécution de
 * toute commande, quel que soit le canal (console, bot Signal).
 *
 * Les bascules vivent dans data/commandes-poste.json, à côté de poste.env : elles survivent au
 * redémarrage même sans Postgres (la base embarquée, elle, repart vide). Sur un disque en lecture
 * seule, une bascule vaut jusqu'au redémarrage, et la console le dit.
 */
import { ecrireFichierPoste, lireFichierPoste } from "../disque-poste.server.ts";
import path from "node:path";
import {
  COMMANDES,
  LIBELLE_CANAL,
  aide,
  analyser,
  basculesValides,
  commandeProche,
  commandeActive,
  executerImage,
  lignesSources,
  type Bascules,
  type Canal,
} from "./commandes-poste";
import { imagePoste } from "./live-feeds";
import type { Journal } from "./recherche-poste.server";

export type ResultatCommande = {
  ok: boolean;
  /** Nom de la commande reconnue ; null si la ligne n'en est pas une, ou une inconnue. */
  commande: string | null;
  lignes: string[];
  /** Temps d'exécution sur le serveur du poste, en millisecondes. */
  ms: number;
  /**
   * Console : la requête que le filtre de souveraineté a refusée, et que le chef de division peut
   * faire sortir (voir rechercheForcee). Absent partout ailleurs.
   */
  forcable?: string;
};

export type EtatBascules = {
  bascules: Bascules;
  /** « fichier » : enregistré sur le poste ; « memoire » : jusqu'au redémarrage. */
  enregistrement: "fichier" | "memoire";
};

type Etat = EtatBascules & { charge: boolean };

const g = globalThis as typeof globalThis & { __afriCommandes?: Etat };

function fichier(): string {
  return path.join(process.cwd(), "data", "commandes-poste.json");
}

async function etat(): Promise<Etat> {
  const e = (g.__afriCommandes ??= { bascules: {}, enregistrement: "fichier", charge: false });
  if (!e.charge) {
    e.charge = true;
    // Illisible : sa copie ; ni l'un ni l'autre : les réglages de livraison.
    const lues = await lireFichierPoste(fichier(), (t) => basculesValides(JSON.parse(t)));
    if (lues) e.bascules = lues;
  }
  return e;
}

export async function lireBascules(): Promise<EtatBascules> {
  const e = await etat();
  return { bascules: e.bascules, enregistrement: e.enregistrement };
}

/** Active ou désactive une commande sur un canal ; effet immédiat, puis enregistré sur le poste. */
export async function basculer(nom: string, canal: Canal, actif: boolean): Promise<EtatBascules> {
  const c = COMMANDES.find((x) => x.nom === nom);
  if (!c) throw new Error(`Commande inconnue : ${nom}`);
  if (c.fixe) throw new Error(`/${nom} ne se désactive pas`);
  const e = await etat();
  e.bascules = { ...e.bascules, [nom]: { ...e.bascules[nom], [canal]: actif } };
  try {
    await ecrireFichierPoste(fichier(), `${JSON.stringify(e.bascules, null, 2)}\n`);
    e.enregistrement = "fichier";
  } catch {
    e.enregistrement = "memoire";
  }
  return { bascules: e.bascules, enregistrement: e.enregistrement };
}

async function capteurs(maintenant: number): Promise<string[]> {
  const lignes = lignesSources(await imagePoste(), maintenant);
  const ia = await import("./ia-poste.server");
  const indispo = ia.iaIndisponible();
  lignes.push(indispo ? `  ✖ IA du poste : ${indispo.erreur}` : "  ✔ IA du poste : réglée");
  return lignes;
}

async function notice(question: string): Promise<string[]> {
  if (!question) return ["/notice attend une question : /notice comment relier Signal ?"];
  const passages = await (await import("./savoir-poste.server")).noticePour(question);
  if (passages.length === 0) return [`La notice du poste ne répond pas à « ${question} ».`];
  return passages.flatMap((p) => [`[${p.titre}]`, p.texte]);
}

/** /recherche : filtre de souveraineté, moteur SearXNG du poste, journal. */
async function recherche(
  question: string,
  canal: Canal,
  journal: Journal,
): Promise<{ ok: boolean; lignes: string[]; forcable?: string }> {
  if (!question)
    return {
      ok: false,
      lignes: ["/recherche attend une requête : /recherche portée d'un drone DJI Mavic 3"],
    };
  const srv = await import("./recherche-poste.server");
  const r = await srv.chercherEnLigne(question, await imagePoste(), journal);
  // Seule la console peut faire sortir sur ordre du chef ; un téléphone, jamais.
  const forcable = !r.ok && r.forcable && canal === "console" ? { forcable: question } : {};
  return { ok: r.ok, lignes: srv.lignesRecherche(r), ...forcable };
}

/**
 * Ordre du chef de division, à la console : la requête que le filtre a refusée sort quand même
 * (journal en sévérité critique). /recherche doit être activée pour la console : l'ordre passe
 * outre au filtre, pas à la bascule.
 */
export async function rechercheForcee(question: string, journal: Journal): Promise<ResultatCommande> {
  const t0 = performance.now();
  const fin = (ok: boolean, lignes: string[]): ResultatCommande => ({
    ok,
    commande: "recherche",
    lignes,
    ms: Math.round((performance.now() - t0) * 100) / 100,
  });
  const { bascules } = await etat();
  const c = COMMANDES.find((x) => x.nom === "recherche")!;
  if (!commandeActive(c, "console", bascules)) {
    return fin(false, [
      "/recherche est désactivée pour la console : l'activer d'abord (Capteurs › Outils › Commandes du poste).",
    ]);
  }
  const srv = await import("./recherche-poste.server");
  const r = await srv.chercherEnLigne(question, await imagePoste(), journal, true);
  return fin(r.ok, [
    "Sortie sur ordre du chef de division, filtre de souveraineté passé outre (journal : critique).",
    ...srv.lignesRecherche(r),
  ]);
}

/**
 * /registre : la requête nomme l'avion et sort du poste. À la console, le chef seul ; par le bot,
 * seulement relevé Internet activé — coupé, aucun téléphone ne fait sortir le nom d'un avion.
 */
async function registre(
  argument: string,
  canal: Canal,
  estChef: () => Promise<boolean>,
  journal: Journal,
): Promise<{ ok: boolean; lignes: string[] }> {
  if (canal === "console" && !(await estChef())) {
    return {
      ok: false,
      lignes: ["/registre est réservée au chef de division : la requête nomme l'avion et sort du poste."],
    };
  }
  const coupe = !(await (await import("./releve-internet.server")).releveInternetActif());
  if (coupe && canal === "bot") {
    return {
      ok: false,
      lignes: ["Relevé Internet coupé : /registre seulement à la console, par le chef."],
    };
  }
  const { cibleRegistre, lignesRegistre, resumeRegistre } = await import("./registre-poste");
  const cible = cibleRegistre(argument, await imagePoste());
  if ("erreur" in cible) return { ok: false, lignes: [cible.erreur] };
  const r = await (await import("./registre-poste.server")).consulterRegistre(cible);
  await journal(`Registre en ligne : ${cible.hex.toUpperCase()}`, resumeRegistre(r), {
    severite: "warn",
    genre: "registre",
  });
  return {
    ok: true,
    lignes: [
      ...lignesRegistre(r),
      ...(coupe ? ["Relevé Internet coupé : cette requête est sortie du poste sur ordre du chef."] : []),
    ],
  };
}

/** /ia : l'agent répond ; sans IA, les lignes des commandes consultées et la notice. */
async function ia(
  question: string,
  canal: Canal,
  journal: Journal,
): Promise<{ ok: boolean; lignes: string[] }> {
  if (!question) {
    return {
      ok: false,
      lignes: ["/ia attend une question : /ia que se passe-t-il au nord du poste ?"],
    };
  }
  const r = await (await import("./agent-poste.server")).repondre(question, canal, journal);
  const consultees = r.competences.length
    ? [`Commandes consultées : ${r.competences.join(", ")}.`]
    : [];
  if (r.ok) return { ok: true, lignes: [...r.text.split("\n"), ...consultees] };
  return {
    ok: false,
    lignes: [
      `${r.error} — sans IA : les valeurs reçues et la notice, sans rédaction.`,
      ...r.faits,
      ...r.notice.map((p) => `[Notice] ${p.titre}`),
      ...consultees,
    ],
  };
}

/** /briefing : rédigé par l'IA du poste à partir des commandes activées du canal. */
async function briefing(canal: Canal): Promise<{ ok: boolean; lignes: string[] }> {
  const r = await (await import("./agent-poste.server")).briefing(canal);
  return r.ok
    ? {
        ok: true,
        lignes: [...r.text.split("\n"), `Commandes consultées : ${r.competences.join(", ")}.`],
      }
    : { ok: false, lignes: [r.error] };
}

/**
 * Exécute une ligne « /commande argument » reçue sur un canal. `journal` : au nom de qui écrire
 * les actions sensibles (une recherche en ligne, un registre). `estChef` : la ligne vient-elle du
 * chef de division ? Demandé seulement par /registre, qui l'exige à la console.
 */
export async function lancer(
  texte: string,
  canal: Canal,
  journal: Journal,
  estChef: () => Promise<boolean> = async () => false,
): Promise<ResultatCommande> {
  const t0 = performance.now();
  const fin = (r: Omit<ResultatCommande, "ms">): ResultatCommande => ({
    ...r,
    ms: Math.round((performance.now() - t0) * 100) / 100,
  });
  const a = analyser(texte);
  if (!a) {
    return fin({ ok: false, commande: null, lignes: ["Une commande commence par « / » : /aide."] });
  }
  if ("inconnue" in a) {
    const proche = commandeProche(a.inconnue);
    return fin({
      ok: false,
      commande: null,
      lignes: [
        `Commande inconnue : /${a.inconnue}.${proche ? ` Vouliez-vous dire /${proche.nom} ?` : ""} /aide pour la liste.`,
      ],
    });
  }
  const { commande, argument } = a;
  const { bascules } = await etat();
  if (!commandeActive(commande, canal, bascules)) {
    return fin({
      ok: false,
      commande: commande.nom,
      lignes: [
        `/${commande.nom} est désactivée au poste pour ${LIBELLE_CANAL[canal]}. Le chef de division l'active dans Capteurs › Outils › Commandes du poste.`,
      ],
    });
  }
  const maintenant = Date.now();
  if (commande.nom === "aide") {
    return fin({ ok: true, commande: "aide", lignes: aide(argument, canal, bascules) });
  }
  if (commande.nom === "capteurs") {
    return fin({ ok: true, commande: "capteurs", lignes: [...(await capteurs(maintenant)), ...(await noteCoupe(canal))] });
  }
  if (commande.nom === "ia")
    return fin({ commande: "ia", ...(await ia(argument, canal, journal)) });
  if (commande.nom === "recherche") {
    return fin({ commande: "recherche", ...(await recherche(argument, canal, journal)) });
  }
  if (commande.nom === "registre") {
    return fin({ commande: "registre", ...(await registre(argument, canal, estChef, journal)) });
  }
  if (commande.nom === "briefing") {
    return fin({ commande: "briefing", ...(await briefing(canal)) });
  }
  if (commande.nom === "notice") {
    return fin({ ok: true, commande: "notice", lignes: await notice(argument) });
  }
  const active = (nom: string) => {
    const c = COMMANDES.find((x) => x.nom === nom);
    return c != null && commandeActive(c, canal, bascules);
  };
  const lignes = executerImage(commande.nom, argument, await imagePoste(), maintenant, active);
  return fin({ ok: true, commande: commande.nom, lignes: [...(lignes ?? []), ...(await noteCoupe(canal))] });
}

/**
 * Console, relevé Internet coupé : la réponse le dit — sans cela, « Pas encore de relevé (en
 * attente) » restait affiché sur un poste neuf, livré coupé. Le bot le dit à sa façon (noteReleve).
 */
async function noteCoupe(canal: Canal): Promise<string[]> {
  if (canal !== "console") return [];
  const actif = await (await import("./releve-internet.server")).releveInternetActif();
  return actif ? [] : ["Relevé Internet coupé : ce qui vient d'Internet n'est pas reçu ; le chef de division l'active dans Capteurs › Outils."];
}
