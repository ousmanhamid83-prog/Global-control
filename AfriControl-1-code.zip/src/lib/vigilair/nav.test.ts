import assert from "node:assert/strict";
import { test } from "node:test";
import {
  axisHazards,
  bearingDeg,
  cardinal,
  destinationPoint,
  distanceKm,
  parsePoints,
  profileCrossings,
  relativeTurn,
  routeTotals,
  safeDetour,
  solve,
  toGpx,
  toWaypointText,
} from "./nav.ts";

test("cap : plein est ≈ 90°, plein nord ≈ 0°", () => {
  // à l'équateur, aller vers l'est = cap 90
  assert.ok(Math.abs(bearingDeg(0, 0, 0, 1) - 90) < 0.5);
  // aller plein nord = cap 0
  assert.ok(Math.abs(bearingDeg(0, 0, 1, 0) - 0) < 0.5);
  // plein ouest = 270
  assert.ok(Math.abs(bearingDeg(0, 0, 0, -1) - 270) < 0.5);
});

test("distance : 1° de latitude ≈ 111 km", () => {
  const d = distanceKm(0, 0, 1, 0);
  assert.ok(Math.abs(d - 111.2) < 1);
});

test("cardinal et ETA", () => {
  assert.equal(cardinal(0), "N");
  assert.equal(cardinal(90), "E");
  assert.equal(cardinal(270), "O");
  const s = solve(12.1, 15.0, 16.027, 22.634, 60); // N'Djamena -> Amdjarass à 60 km/h
  assert.ok(s.distanceKm > 700 && s.distanceKm < 1100);
  assert.ok(s.bearingDeg > 45 && s.bearingDeg < 90); // vers le nord-est
  assert.ok(s.etaMin && s.etaMin > 700); // plusieurs heures
});

test("relativeTurn signe : droite positif, gauche négatif", () => {
  assert.equal(relativeTurn(0, 90), 90); // tourner 90° à droite
  assert.equal(relativeTurn(0, 270), -90); // 90° à gauche
  assert.equal(relativeTurn(350, 10), 20); // passage 360°
});

test("axisHazards : un danger sur l'axe est retenu, un danger loin est ignoré", () => {
  // axe plein est de (0,0) à (0,4) ; danger à mi-chemin, 10 km au nord -> retenu
  const near = { id: "n", kind: "feu", lat: 0.09, lon: 2, title: "foyer" }; // ~10 km au nord
  const far = { id: "f", kind: "inondation", lat: 5, lon: 2, title: "crue loin" }; // ~555 km au nord
  const haz = axisHazards(0, 0, 0, 4, [near, far], 25, 5);
  assert.equal(haz.length, 1);
  assert.equal(haz[0]!.id, "n");
  assert.ok(haz[0]!.offsetKm < 25 && haz[0]!.offsetKm > 5);
  assert.ok(haz[0]!.alongKm > 150 && haz[0]!.alongKm < 300); // ~ moitié de ~445 km
  assert.equal(haz[0]!.side, "gauche"); // nord de l'axe est→ sur un cap est, le nord est à gauche
});

test("destinationPoint : 111 km plein nord ≈ +1° de latitude", () => {
  const [lat, lon] = destinationPoint(0, 0, 0, 111.2);
  assert.ok(Math.abs(lat - 1) < 0.02);
  assert.ok(Math.abs(lon) < 0.001);
});

test("routeTotals : somme des étapes", () => {
  const r = routeTotals([{ lat: 0, lon: 0 }, { lat: 0, lon: 1 }, { lat: 0, lon: 2 }], 60);
  assert.equal(r.legs.length, 2);
  assert.ok(Math.abs(r.distanceKm - 222.4) < 2);
  assert.ok(r.etaMin && Math.abs(r.etaMin - 222.4) < 3);
});

test("safeDetour : axe dégagé → clear ; obstacle sur l'axe → point de contournement qui dégage", () => {
  const far = [{ id: "x", kind: "feu", lat: 9, lon: 0.5, title: "loin" }]; // ~1000 km au nord
  assert.deepEqual(safeDetour(0, 0, 0, 1, far, 25), { clear: true });

  const onAxis = [{ id: "y", kind: "inondation", lat: 0, lon: 0.5, title: "sur l'axe" }]; // pile au milieu
  const d = safeDetour(0, 0, 0, 1, onAxis, 25);
  assert.equal(d.clear, false);
  if (d.clear === false && d.waypoint) {
    // les deux demi-étapes doivent être dégagées
    assert.equal(axisHazards(0, 0, d.waypoint.lat, d.waypoint.lon, onAxis, 25).length, 0);
    assert.equal(axisHazards(d.waypoint.lat, d.waypoint.lon, 0, 1, onAxis, 25).length, 0);
  } else {
    assert.fail("un contournement aurait dû être trouvé");
  }
});

test("toGpx : XML valide avec rte/rtept et wpt obstacle", () => {
  const g = toGpx("Test", [{ lat: 12.1, lon: 15.0, name: "A" }, { lat: 16.0, lon: 22.6, name: "B" }], [{ lat: 14, lon: 18, name: "crue" }]);
  assert.match(g, /<gpx /);
  assert.match(g, /<rte><name>Test<\/name>/);
  assert.match(g, /<rtept lat="12\.100000" lon="15\.000000">/);
  assert.match(g, /<wpt[^>]*><name>crue<\/name>/);
  assert.match(g, /<\/gpx>/);
});

test("toWaypointText : lignes lat, lon", () => {
  const t = toWaypointText([{ lat: 12.12345, lon: 15.05 }, { lat: 16, lon: 22, name: "Cible" }]);
  assert.equal(t.split("\n").length, 2);
  assert.match(t, /P1: 12\.12345, 15\.05000/);
  assert.match(t, /Cible: 16\.00000, 22\.00000/);
});

test("profileCrossings : pente et altitude au-delà du seuil", () => {
  // deux points espacés de 1 km avec +300 m => pente 30 %
  const c = profileCrossings([{ alongKm: 0, elevM: 400 }, { alongKm: 1, elevM: 700 }], 15, 600);
  assert.ok(c.maxSlopePct > 29 && c.maxSlopePct < 31);
  assert.equal(c.slopeExceeded, true);
  assert.equal(c.maxElevM, 700);
  assert.equal(c.altExceeded, true);
  // plat et bas => rien
  const flat = profileCrossings([{ alongKm: 0, elevM: 300 }, { alongKm: 10, elevM: 305 }], 15, 1000);
  assert.equal(flat.slopeExceeded, false);
  assert.equal(flat.altExceeded, false);
});

test("parsePoints : noms + coordonnées, formats variés, lignes invalides ignorées", () => {
  const txt = [
    "# commentaire",
    "Komé, 8.5428, 16.7806",
    "15.45, 36.40",
    "Poste 12 : 12.5  22.6",
    "ligne sans coord",
    "999, 0",
  ].join("\n");
  const pts = parsePoints(txt);
  assert.equal(pts.length, 3);
  assert.deepEqual(pts[0], { lat: 8.5428, lon: 16.7806, name: "Komé" });
  assert.deepEqual(pts[1], { lat: 15.45, lon: 36.4, name: undefined });
  assert.deepEqual(pts[2], { lat: 12.5, lon: 22.6, name: "Poste 12" });
});
