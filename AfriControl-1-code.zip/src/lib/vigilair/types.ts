import type { PosSource } from "./integrity.ts";

export type Origin = "CN" | "TR" | "RU" | "IR" | "XX";

/** fatl / asecna : affiliation amie ; civil : trafic 1090ES coopératif hors zone ASECNA (neutre) ; drone : un de NOS drones inscrits. */
export type FriendKind = "fatl" | "asecna" | "civil" | "drone";

export type IffMode = "3/A" | "S" | "ADS-B" | "4";

export type IffM4State = "absent" | "valid" | "invalid" | "timeout" | "demande";

export type ModeSDf =
  | "DF0"
  | "DF4"
  | "DF5"
  | "DF11"
  | "DF16"
  | "DF17"
  | "DF20"
  | "DF21";

export type ModeSSurveillance = "none" | "els" | "ehs" | "adsb";

export type ModeSReply = {
  id: string;
  df: ModeSDf;
  label: string;
  icao24: string;
  at: number;
  siteId: string;
  siteName: string;
  bds: string | null;
  payload: string;
  solicited: boolean;
};

export type MlatFix = {
  lat: number;
  lon: number;
  quality: number;
  nSites: number;
  sites: string[];
  residualKm: number;
  adsbDeltaKm: number | null;
  spoofSuspect: boolean;
  at: number;
  note: string;
};

export type IffFix = {
  mode: IffMode;
  squawk: string;
  icao24: string | null;
  flightId: string;
  source: "iff-fatl" | "adsb-asecna" | "iff-ssr";
  /** Mode 4 crypto — réponse à un interrogateur externe, pas une émission AfriControl. */
  m4: IffM4State;
  m4At: number | null;
  m4Site: string | null;
  m4Note: string;
  /** Couche Mode S (ELS / EHS / ADS-B). Absent = pas de transpondeur 1090. */
  surveillance?: ModeSSurveillance;
  replies?: ModeSReply[];
  mlat?: MlatFix | null;
  /** Position revendiquée par DF17 — pour détecter une usurpation ADS-B. */
  adsbClaim?: { lat: number; lon: number } | null;
  lastReplyAt?: number | null;
};


export type UasClass =
  | "multirotor"
  | "fixed-wing"
  | "vtol"
  | "loitering"
  | "male"
  | "ucav"
  | "chasse";

export type Role =
  | "consumer"
  | "enterprise-isr"
  | "agriculture"
  | "logistics"
  | "isr"
  | "strike"
  | "loitering-munition"
  | "mothership"
  | "fighter"
  | "trainer"
  | "rotary"
  | "airliner"
  | "transport";

export type Threat = "faible" | "moderee" | "elevee" | "critique";

export type IdState =
  | "detecte"
  | "classification"
  | "candidat"
  | "confirme"
  | "hors-mandat"
  | "perdu";

export type SensorKind = "rf" | "radar" | "eoir" | "acoustic";

export type AudioChannel = "acoustic" | "analog-fpv" | "blocked-crypto" | "none";

export type AcousticBearing = {
  siteId: string;
  deg: number;
  quality: number;
};

export type AcousticState = {
  snrDb: number;
  bpfHz: number;
  harmonics: [number, number, number];
  bearings: AcousticBearing[];
  channel: AudioChannel;
  channelNote: string;
  splDb: number;
  locked: boolean;
};

export type PilotFix = {
  lat: number;
  lon: number;
  quality: number;
  method: string;
};

export type SiteCpa = {
  siteId: string;
  name: string;
  distKm: number;
  etaS: number | null;
  closing: boolean;
};

export type ProtectedSite = {
  id: string;
  name: string;
  kind: "aerodrome" | "palais" | "camp" | "pont" | "ministere";
  lat: number;
  lon: number;
  radiusKm: number;
};

export type AudioClip = {
  id: string;
  at: number;
  trackId: string;
  callsign: string;
  bpfHz: number;
  channel: AudioChannel;
  durationS: number;
  note: string;
};

export type TraceFix = {
  lat: number;
  lon: number;
  at: number;
  quality: number;
  method: string;
  predicted: boolean;
};

export type SigintStream = {
  id: string;
  label: string;
  state: "lock" | "scan" | "denied";
  detail: string;
};

export type EvidencePack = {
  satScene: string;
  satCredit: string;
  sarNote: string;
  sceneNote: string;
  launch: TraceFix;
  stop: TraceFix;
  c2: PilotFix | null;
  path: { lat: number; lon: number }[];
  sensors: SensorKind[];
  method: string;
  launchTile: string;
  c2Tile: string | null;
  stopTile: string;
};

export type DefensePosture = "veille" | "alerte" | "menace";

export type EwState = "idle" | "demande" | "effet" | "refuse";

export type EwRequest = {
  state: EwState;
  at: number;
  note: string;
};

export type Platform = {
  id: string;
  name: string;
  manufacturer: string;
  origin: Origin;
  originLabel: string;
  uasClass: UasClass;
  role: Role;
  threat: Threat;
  massKg: number;
  enduranceMin: number;
  rangeKm: number;
  ceilingM: number;
  cruiseKmh: number;
  maxKmh: number;
  rfBands: string[];
  protocol: string;
  remoteId: boolean;
  payload: string;
  cues: {
    rf: string;
    visual: string;
    kinematic: string;
    acoustic: string;
  };
  notes: string;
  /** Présent uniquement sur les fiches de la couche amis. */
  friendKind?: FriendKind;
};

export type Hypothesis = {
  platformId: string;
  score: number;
};

export type Track = {
  id: string;
  callsign: string;
  lat: number;
  lon: number;
  altM: number;
  heading: number;
  speedKmh: number;
  climbMs: number;
  trail: { lat: number; lon: number }[];
  truePlatformId: string;
  idState: IdState;
  confidence: number;
  /**
   * Pourquoi cette confiance (pistes réelles) : type déclaré au registre, type inconnu, adresse
   * ICAO douteuse… Le chiffre seul était tapé en dur à 99 % pour tout le trafic réel ; un score
   * qui se justifie se lit, un score muet se croit.
   */
  confidenceNote?: string;
  /**
   * L'indicatif affiché a-t-il été ÉMIS par l'appareil ? À défaut, `callsign` se replie sur
   * l'immatriculation ou l'adresse — pour l'affichage seulement : ce repli n'est pas une preuve.
   */
  callsignTx?: boolean;
  origin: Origin | null;
  classGuess: UasClass | null;
  hypotheses: Hypothesis[];
  sensors: SensorKind[];
  firstSeen: number;
  lastUpdate: number;
  dwellS: number;
  confirmedAt: number | null;
  motion: "transit" | "loiter" | "ingress";
  loiterCx: number;
  loiterCy: number;
  loiterR: number;
  turnRate: number;
  acoustic: AcousticState | null;
  pilotFix: PilotFix | null;
  cpa: SiteCpa | null;
  siteWarned: boolean;
  launchFix: TraceFix | null;
  stopFix: TraceFix | null;
  locked: boolean;
  corridor: string | null;
  ew: EwRequest | null;
  /** Piste créée par un inject de formation (AAR). */
  injected?: boolean;
  /** FATL / ASECNA — affiliation amie, distincte de l'origine constructeur. */
  friendKind?: FriendKind;
  /** Nom de NOTRE drone (registre du poste) quand cette piste a été appariée à un drone inscrit. */
  ownDrone?: string;
  /**
   * PISTE MÉMOIRE : la piste n'émet plus, la position affichée est EXTRAPOLÉE à l'estime, pas
   * mesurée. `silentS` = durée du silence, `radiusKm` = incertitude autour du point prédit.
   * Absent tant que la piste émet normalement.
   */
  coast?: { silentS: number; radiusKm: number };
  /**
   * Dernier relevé REFUSÉ parce que physiquement impossible (trame brouillée, décodage faux ou
   * position falsifiée) : contient le motif. Incohérence de signal, jamais une identité.
   */
  suspectJump?: string;
  /**
   * Épisode de relevés incohérents en cours : combien, depuis quand, et quand remonte le dernier.
   * La RÉPÉTITION est ce qui trahit une adresse ICAO tenue par deux émetteurs — un refus isolé est
   * seulement une trame ratée. L'épisode se referme un délai après le dernier incident.
   */
  suspect?: { run: number; since: number; at: number };
  /**
   * Dernière position MESURÉE et son heure RÉELLE d'observation. Un agrégateur réseau livre des
   * positions déjà vieilles de plusieurs dizaines de secondes (champ `seen`) : prendre l'heure de
   * réception pour l'heure d'observation place le symbole des kilomètres à côté, en silence.
   * `lat`/`lon` de la piste sont le meilleur ESTIMÉ pour maintenant ; `fix` est la mesure brute,
   * qui seule permet de comparer deux relevés sur leur vrai intervalle. C'est la dernière
   * observation COMPTÉE (voir `fixes`) : une même position revue à moins de 2 s ne la remplace pas.
   */
  fix?: { lat: number; lon: number; at: number };
  /**
   * Observations DISTINCTES acceptées sur la piste. Un agrégateur qui resservait le même rapport
   * (même position, même heure à quelques millisecondes) comptait comme une observation de plus :
   * des pistes vues une seule fois passaient « confirmées ». Les relevés refusés n'y entrent pas.
   */
  fixes?: number;
  iff?: IffFix | null;
  /** Origine de la piste : sim COP, 1090ES live, Remote ID, ou rejeu de 1090ES réellement reçu. */
  feed?: "sim" | "adsb" | "rid" | "rejeu";
  /** Piste de REJEU RÉEL : heure d'origine de la position et bande d'où elle vient. Jamais live. */
  rejeu?: { posAt: number; kind: "poste" | "archive"; source: string; trailAt: number };
  icaoType?: string | null;
  reg?: string | null;
  emergency?: string | null;
  rssi?: number | null;
  /** Navigation Integrity Category (ADS-B). Bas = GNSS dégradé / jamming. */
  nic?: number | null;
  nacp?: number | null;
  /**
   * Provenance de la POSITION : « adsb » = émise par l'aéronef (et donc porteuse d'un NIC),
   * « mlat » = calculée par multilatération depuis le réseau de récepteurs (aucun NIC à dégrader).
   * Sans cette distinction, l'absence de NIC d'une piste MLAT passait pour un GNSS brouillé.
   */
  posSource?: PosSource;
  /**
   * Rayon de confinement de la position (km) : ce que l'aéronef admet lui-même ignorer de sa
   * position, ou le plancher retenu pour une position calculée. null = non annoncé. Le symbole
   * ponctuel seul laissait croire à une précision métrique sur des pistes à plusieurs kilomètres.
   */
  posRcKm?: number | null;
  /** D'où vient ce rayon (rayon annoncé, table NIC, multilatération) : à afficher, pas à taire. */
  posRcNote?: string;
  military?: boolean;
  category?: string | null;
  /** Nationalité ICAO24 (allocation OACI, pas une simulation). */
  nation?: string | null;
};

export type SensorSite = {
  id: string;
  name: string;
  kind: SensorKind;
  lat: number;
  lon: number;
  rangeKm: number;
  online: boolean;
};

export type AlertItem = {
  id: string;
  trackId: string;
  at: number;
  level: Threat;
  title: string;
  body: string;
  acked: boolean;
  /** sigint = écoute passive. Les autres alertes n'ont pas de domaine. */
  domain?: "sigint";
  /** Ne pas relayer Telegram / Signal (inject de formation). */
  injected?: boolean;
  lat?: number;
  lon?: number;
};

export type JournalEntry = {
  id: string;
  at: number;
  trackId: string;
  callsign: string;
  platformId: string;
  origin: Origin;
  confidence: number;
  lat: number;
  lon: number;
  altM: number;
  sensors: SensorKind[];
  method: string;
  launchLat?: number;
  launchLon?: number;
  stopLat?: number;
  stopLon?: number;
  c2Lat?: number;
  c2Lon?: number;
  ewNote?: string;
  filedBy?: string;
  contentSha256?: string;
  prevSha256?: string | null;
  chainSha256?: string;
  pdfSha256?: string;
  injected?: boolean;
  pending?: boolean;
  fileError?: string;
};
