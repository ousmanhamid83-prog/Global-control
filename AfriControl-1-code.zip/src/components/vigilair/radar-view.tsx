import { PpiRadar } from "@/components/vigilair/ppi-radar";
import { RhiRadar } from "@/components/vigilair/rhi-radar";
import { PaintFilters } from "@/components/vigilair/paint-filters";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { PLATFORM_BY_ID, classLabel, originLabel } from "@/lib/vigilair/catalog";
import { AO, formatCoord, haversineKm, headingBetween } from "@/lib/vigilair/geo";
import { iffModesLine, passesPaintFilter } from "@/lib/vigilair/iff";
import { surveillanceLabel } from "@/lib/vigilair/mode-s";
import { PPI_RANGES, TIME_VECTORS, type PpiRangeKm } from "@/lib/vigilair/ppi";
import { useStaff } from "@/lib/vigilair/staff-context";
import { affiliationLabel, affiliationOf } from "@/lib/vigilair/app6";
import { rejeuClock } from "@/lib/vigilair/rejeu";
import { threatOf, useVigilair } from "@/lib/vigilair/store";
import type { Track } from "@/lib/vigilair/types";
import { cn } from "@/lib/utils";
import { Crosshair, EyeOff } from "lucide-react";
import { useMemo } from "react";

export function RadarView() {
  const ppi = useVigilair((s) => s.ppi);
  const setPpi = useVigilair((s) => s.setPpi);
  const tracks = useVigilair((s) => s.tracks);
  const selectedId = useVigilair((s) => s.selectedId);
  const lockTrack = useVigilair((s) => s.lockTrack);
  const selected = tracks.find((t) => t.id === selectedId);
  // S'abonner aux filtres de peinture pour que la liste et le compteur se rafraîchissent
  // IMMÉDIATEMENT au basculement (débruitage, menace, amis, live), pas au relevé suivant.
  const declutter = useVigilair((s) => s.declutter);
  const threatFloor = useVigilair((s) => s.threatFloor);
  const showFriends = useVigilair((s) => s.showFriends);
  const showLive = useVigilair((s) => s.showLive);
  // On applique le filtre de peinture avec les valeurs NOMMÉES plutôt que via trackVisible, qui les
  // relit par getState : la dépendance devient réelle au lieu d'être masquée, donc la liste se
  // recalcule bien au basculement d'un filtre, sans avoir à museler la règle des dépendances.
  const live = useMemo(
    () =>
      tracks.filter((t) =>
        passesPaintFilter(t, { declutter, threatFloor, showFriends, showLive, selectedId }),
      ),
    [tracks, selectedId, declutter, threatFloor, showFriends, showLive],
  );
  const { isSuperadmin } = useStaff();

  return (
    <div className="grid min-h-0 flex-1 overscroll-contain grid-cols-[minmax(0,1fr)_300px] grid-rows-[minmax(0,1fr)] overflow-hidden">
      <section className="relative grid min-h-0 border-border grid-rows-[minmax(0,1fr)_9rem] border-b-0 border-r">
        <PpiRadar className="min-h-0" />
        <div className="min-h-0 border-t border-border">
          <RhiRadar className="h-full" />
        </div>
      </section>
      <aside className="min-h-0 overflow-y-auto">
        <div className="space-y-4 p-4">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
              Paramètres PPI
            </p>
            <h2 className="text-base font-semibold">Écran des pistes FTTJ</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              PPI + coupe altitude RHI — pistes 1090ES reçues en direct (antenne du poste et
              relevé réseau). Le poste n'a pas de radar primaire : aucun balayage n'est simulé.
              Symboles APP-6 (le cadre = l'affiliation). Réception seule : AfriControl n'émet
              pas. Espace = pause · L = verrouiller · F = amis · T = menace · D = débruitage ·
              1–9 = portée · ← → AAR.
            </p>
          </div>

          <div>
            <p className="mb-2 text-xs text-muted-foreground">Portée</p>
            <div className="flex flex-wrap gap-1">
              {PPI_RANGES.map((km) => (
                <button
                  key={km}
                  type="button"
                  onClick={() => setPpi({ rangeKm: km as PpiRangeKm })}
                  className={cn(
                    "h-9 rounded-md px-3 text-xs transition-colors duration-150",
                    ppi.rangeKm === km
                      ? "bg-secondary text-fg"
                      : "text-muted-foreground hover:bg-secondary hover:text-fg",
                  )}
                >
                  {km} km
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="mb-2 text-xs text-muted-foreground">Peinture</p>
            <PaintFilters variant="rail" />
          </div>

          <div className="grid grid-cols-2 gap-1">
            {(
              [
                ["symbols", "Symboles APP-6"],
                ["labels", "Étiquettes"],
                ["trails", "Trajectoires"],
                ["iff", "Squawk"],
                ["northTrue", ppi.northTrue ? "Nord vrai" : "Nord mag."],
              ] as const
            ).map(([key, lab]) => (
              <button
                key={key}
                type="button"
                onClick={() => setPpi({ [key]: !ppi[key] })}
                className={cn(
                  "h-11 rounded-md px-3 text-xs transition-colors duration-150",
                  ppi[key]
                    ? "bg-secondary text-fg"
                    : "text-muted-foreground hover:bg-secondary",
                )}
              >
                {lab}
              </button>
            ))}
          </div>

          <div>
            <p className="mb-2 text-xs text-muted-foreground">Vecteur vitesse</p>
            <div className="flex flex-wrap gap-1">
              {TIME_VECTORS.map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setPpi({ timeVector: m })}
                  className={cn(
                    "h-9 rounded-md px-3 text-xs transition-colors duration-150",
                    ppi.timeVector === m
                      ? "bg-secondary text-fg"
                      : "text-muted-foreground hover:bg-secondary hover:text-fg",
                  )}
                >
                  {m === 0 ? "aucun" : `${m} min`}
                </button>
              ))}
            </div>
          </div>

          {ppi.symbols ? <App6Legend /> : null}

          <dl className="grid grid-cols-2 gap-2 text-xs">
            <Item label="Site" value="FTTJ" />
            <Item label="Pistes dans le PPI" value={`${live.filter((t) => haversineKm(AO.airport.lat, AO.airport.lon, t.lat, t.lon) <= ppi.rangeKm).length}`} />
            {/* Pistes dont la position est EXTRAPOLÉE (transpondeur muet), et relevés refusés comme
                physiquement impossibles. L'opérateur doit savoir ce qui est mesuré et ce qui ne l'est pas. */}
            <Item label="Pistes mémoire" value={`${live.filter((t) => t.coast).length}`} />
            <Item label="Relevés douteux" value={`${live.filter((t) => t.suspectJump).length}`} />
            {/* Positions CALCULÉES par multilatération : l'aéronef n'en émet aucune, c'est notre
                réseau de récepteurs qui l'a située. Moins précis, et sans NIC — donc à ne jamais
                confondre avec un GNSS brouillé. Mesuré : 10 % du trafic réel. */}
            <Item label="Positions calculées" value={`${live.filter((t) => t.posSource === "mlat").length}`} />
          </dl>

          <div className="flex items-center gap-2">
            <Badge tone="ok">
              <EyeOff className="mr-1 size-3" />
              Silencieux
            </Badge>
            {isSuperadmin ? (
              <Badge>Chef de division</Badge>
            ) : (
              <Badge>Admin · détection</Badge>
            )}
          </div>

          {selected ? (
            <div className="space-y-2 rounded-md border border-border p-3">
              <p className="font-mono text-xs text-muted-foreground">{selected.callsign}</p>
              <p className="text-sm font-medium">
                {(() => {
                  const plat =
                    PLATFORM_BY_ID[
                      selected.hypotheses[0]?.platformId ?? selected.truePlatformId
                    ];
                  return plat
                    ? `${plat.manufacturer} ${plat.name}`
                    : "Piste en cours d'ident";
                })()}
              </p>
              <p className="font-mono text-xs tabular-nums text-muted-foreground">
                {formatCoord(selected.lat, selected.lon)}
              </p>
              <p className="text-xs text-muted-foreground">
                BRG{" "}
                {headingBetween(
                  AO.airport.lat,
                  AO.airport.lon,
                  selected.lat,
                  selected.lon,
                ).toFixed(0)}
                ° · RNG{" "}
                {haversineKm(
                  AO.airport.lat,
                  AO.airport.lon,
                  selected.lat,
                  selected.lon,
                ).toFixed(1)}{" "}
                km
                {selected.classGuess ? ` · ${classLabel(selected.classGuess)}` : ""}
                {selected.origin ? ` · ${originLabel(selected.origin)}` : ""}
              </p>
              {selected.iff ? (
                <div className="flex flex-wrap items-center gap-1">
                  <Badge>{surveillanceLabel(selected.iff.surveillance)}</Badge>
                  <span className="text-xs text-muted-foreground">
                    {iffModesLine(selected.iff)}
                  </span>
                </div>
              ) : null}
              <Intercept t={selected} />
              <Button
                variant={selected.locked ? "default" : "outline"}
                size="sm"
                className="w-full"
                onClick={() => lockTrack(selected.locked ? null : selected.id)}
              >
                <Crosshair />
                {selected.locked ? "Trajectoire verrouillée" : "Verrouiller"}
              </Button>
            </div>
          ) : (
            <p className="text-xs text-muted-foreground">
              Cliquez un contact sur l'écran pour verrouiller sa trajectoire.
            </p>
          )}
        </div>
      </aside>
    </div>
  );
}

const APP6_LEGEND: { a: string; label: string; color: string; shape: string }[] = [
  { a: "ami", label: "Ami (nos drones / ASECNA)", color: "var(--color-ok)", shape: "arc" },
  { a: "hostile", label: "Hostile (mandat + menace)", color: "var(--color-crit)", shape: "diamond" },
  { a: "suspect", label: "Suspect (à lever)", color: "var(--color-warn)", shape: "diamond" },
  { a: "neutre", label: "Neutre (civil hors mandat)", color: "var(--color-series-2)", shape: "square" },
  { a: "inconnu", label: "Inconnu (par défaut)", color: "var(--color-muted-foreground)", shape: "clover" },
];

/** Petit glyphe APP-6 air (ouvert en bas) pour la légende. */
function GlyphAir({ shape, color }: { shape: string; color: string }) {
  const common = { fill: "none", stroke: color, strokeWidth: 1.6, strokeLinejoin: "round" as const };
  return (
    <svg width="20" height="16" viewBox="-10 -9 20 18" aria-hidden className="shrink-0">
      {shape === "arc" ? (
        <path d="M -6 7 L -6 0 A 6 6 0 0 1 6 0 L 6 7" {...common} />
      ) : shape === "diamond" ? (
        <path d="M -7 1 L 0 -8 L 7 1" {...common} />
      ) : shape === "square" ? (
        <path d="M -6 7 L -6 -6 L 6 -6 L 6 7" {...common} />
      ) : (
        <path
          d="M -7 4 A 4 4 0 0 1 -7 -4 A 4 4 0 0 1 0 -4 A 4 4 0 0 1 7 -4 A 4 4 0 0 1 7 4"
          {...common}
        />
      )}
    </svg>
  );
}

function App6Legend() {
  return (
    <div className="rounded-md border border-border p-3">
      <p className="mb-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
        Symbologie APP-6 · air
      </p>
      <ul className="space-y-1.5">
        {APP6_LEGEND.map((row) => (
          <li key={row.a} className="flex items-center gap-2 text-xs">
            <GlyphAir shape={row.shape} color={row.color} />
            <span className="text-fg">{row.label}</span>
          </li>
        ))}
      </ul>
      <p className="mt-2 text-[11px] leading-snug text-muted-foreground">
        Le cadre dit l'affiliation, ouvert en bas = aérien. Inconnu est l'état assumé : sans
        affiliation amie ni mandat levé, une piste reste inconnue, jamais hostile par défaut.
      </p>
    </div>
  );
}

const AFFIL_TONE: Record<string, "ok" | "crit" | "warn" | "default"> = {
  ami: "ok",
  hostile: "crit",
  suspect: "warn",
  neutre: "default",
  inconnu: "default",
};

/**
 * Interception : toutes les données réellement reçues de la piste, en clair. AfriControl écoute,
 * ne répond pas. Rien n'est affiché qui n'ait été entendu — les champs absents restent « — ».
 */
function Intercept({ t }: { t: Track }) {
  const { affiliation, reason } = affiliationOf(t, threatOf(t));
  const hex = t.feed === "exercice" ? "—" : t.id.replace(/^(live|rej)-/, "").toUpperCase();
  const fl = Math.round(t.altM / 30.48);
  const via =
    t.feed === "rejeu" && t.rejeu
      ? `REJEU RÉEL · reçu le ${rejeuClock(t.rejeu.posAt)}`
      : t.exercice
        ? `EXERCICE · liaison MAVLink de ${t.exercice.drone}`
        : t.sensors.includes("antenne")
          ? "Antenne du poste"
          : "1090ES réseau";
  const rows: [string, string][] = [
    ["Affiliation", `${affiliationLabel(affiliation)} · ${reason}`],
    ["Reçu par", via],
    ["ICAO24", hex],
    ["Indicatif", t.callsign || "—"],
    ["Type / immat.", `${t.icaoType ?? "—"}${t.reg ? ` · ${t.reg}` : ""}`],
    ["Nationalité", t.nation ?? "—"],
    ["Catégorie", t.category ?? "—"],
    ["Altitude", `${Math.round(t.altM)} m · FL${String(Math.max(0, fl)).padStart(3, "0")}`],
    ["Vitesse sol", `${Math.round(t.speedKmh)} km/h`],
    ["Cap", `${Math.round(t.heading)}°`],
    ["Montée", t.climbMs ? `${t.climbMs > 0 ? "+" : ""}${Math.round(t.climbMs * 196.85)} ft/min` : "—"],
    ["Squawk", t.iff?.squawk ?? "—"],
    ["Intégrité GNSS", t.nic != null ? `NIC ${t.nic}${t.nic < 5 ? " · dégradé" : ""}` : "—"],
    ["Précision", t.nacp != null ? `NACp ${t.nacp}` : "—"],
    ["Signal", t.rssi != null ? `${t.rssi.toFixed(1)} dBFS` : "—"],
    ["Militaire", t.military ? "indicatif militaire" : "—"],
    ["Urgence", t.emergency ?? "—"],
  ];
  return (
    <div className="space-y-2 rounded-md border border-border bg-bg/40 p-2.5">
      <div className="flex items-center justify-between gap-2">
        <p className="text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
          Interception · données reçues
        </p>
        <Badge tone={AFFIL_TONE[affiliation] ?? "default"}>{affiliationLabel(affiliation)}</Badge>
      </div>
      <dl className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1 font-mono text-[11px]">
        {rows.map(([k, v]) => (
          <div key={k} className="contents">
            <dt className="text-muted-foreground">{k}</dt>
            <dd className={cn("truncate text-right tabular-nums", v === "—" ? "text-muted-foreground" : "text-fg")} title={v}>
              {v}
            </dd>
          </div>
        ))}
      </dl>
      <p className="text-[10px] leading-snug text-muted-foreground">
        Lecture passive 1090ES / Mode S. AfriControl n'interroge pas et n'émet pas.
      </p>
    </div>
  );
}

function Item({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="font-mono tabular-nums">{value}</dd>
    </div>
  );
}
