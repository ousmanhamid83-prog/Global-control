#!/usr/bin/env bash
# Prépare le poste AfriControl en une commande. À lancer UNE FOIS EN LIGNE, depuis le dossier
# AfriControl ; ensuite tout tourne hors ligne. Les réglages vont dans poste.env, que le serveur
# lit seul au démarrage (src/lib/config-poste.ts).
#
#   bash scripts/poste/preparer-poste.sh                         IA + relief + serveur construit
#   bash scripts/poste/preparer-poste.sh --itineraire --signal   + itinéraire et relais Signal
#
#   --modele NOM     modèle d'IA (défaut selon la mémoire : qwen2.5:7b dès 15 Go, qwen2.5:3b dès
#                    7 Go, sinon qwen2.5:1.5b)
#   --zone S,N,O,E   relief sur cette zone, en degrés entiers ; RÉPÉTABLE pour couvrir plusieurs
#                    théâtres sur n'importe quels continents (défaut : le Tchad, 7,23,13,23 —
#                    187 tuiles, 862 Mo). Ex. : --zone 7,23,13,23 --zone 42,48,1,8
#   --imagerie       mosaïque Sentinel-2 HORS LIGNE (zooms 8 à 12), avec le compte Copernicus
#                    gratuit de l'opérateur : AFRICONTROL_SENTINEL_ID et _SECRET dans poste.env.
#                    Une tuile = une requête sur le quota mensuel du compte.
#   --zone-imagerie S,N,O,E   zone de la mosaïque, en degrés décimaux (implique --imagerie) ;
#                    RÉPÉTABLE (défaut : le poste, FTTJ ± 0,55° — 274 tuiles).
#                    Ex. : --zone-imagerie 11.6,12.7,14.5,15.6 --zone-imagerie 13.2,13.9,20.5,21.2
#                    Autres réglages (zooms, fenêtre, nuages) : node scripts/poste/imagerie-poste.mjs --help
#   --itineraire     serveur d'itinéraire OSRM du poste (Docker, carte OSM du Tchad, 151 Mo)
#   --signal         relais Signal du poste (Docker) : le détail des alertes, chiffré jusqu'aux
#                    téléphones des destinataires
#   --recherche      moteur de recherche SearXNG du poste (Docker), pour la commande /recherche :
#                    la requête sort alors du poste ; /recherche reste désactivée tant que le chef
#                    de division ne l'active pas (Capteurs › Outils › Commandes du poste)
#   --antenne LAT,LON  antenne 1090 MHz du poste, à cette position (degrés décimaux) : le récepteur
#                    dump1090 est installé (paquet dump1090-mutability), réglé sur elle et lancé avec
#                    la machine, sur une clé radio RTL-SDR ; le poste décode lui-même ses trames
#                    brutes (127.0.0.1:30002). Réception seule : rien n'est émis.
#   --recepteur-1090 HOTE:PORT  un récepteur 1090 déjà en place (trames brutes AVR) au lieu de
#                    l'installer ici ; avec --antenne pour sa position
#   --phonie URL     flux audio de la phonie ATC, sortie du récepteur VHF de l'opérateur
#                    (rtl_airband, Icecast…) : le poste l'enregistre à la demande, doublé et scellé
#   --copies DOSSIER dossier des copies du poste (AFRICONTROL_COPIES) : tout ce que le poste garde y
#                    est doublé aussitôt. Sans --copies, un autre disque INTERNE de la machine (ni
#                    clé ni disque USB, ni autre partition du disque du poste ; le plus de place
#                    libre, 10 Go au moins), s'il y en a un ; sinon data/copies, sur le disque du
#                    poste — sa panne emporterait les deux, le bilan le dit.
#   --sans-build  --sans-ia  --sans-relief    sauter une étape
#
# Relancer le script reprend là où il s'était arrêté : ce qui est déjà en place est gardé.
set -euo pipefail

cd "$(dirname "$0")/../.."
RACINE=$PWD
POSTE_ENV=$RACINE/poste.env
OSRM_IMAGE=ghcr.io/project-osrm/osrm-backend:v26.11.0-debian
SIGNAL_IMAGE=bbernhard/signal-cli-rest-api:0.101
SEARXNG_IMAGE=searxng/searxng:2026.11.2-cccbc9e15

MODELE=""
COPIES=""
ANTENNE=""
RECEPTEUR_1090=""
PHONIE=""
ZONES=()
ZONES_IMAGERIE=()
BUILD=1 IA=1 RELIEF=1 IMAGERIE=0 ITINERAIRE=0 SIGNAL=0 RECHERCHE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --modele) MODELE=${2:?--modele attend un nom de modèle}; shift ;;
    --zone) ZONES+=("${2:?--zone attend S,N,O,E}"); shift ;;
    --imagerie) IMAGERIE=1 ;;
    --zone-imagerie) IMAGERIE=1; ZONES_IMAGERIE+=("${2:?--zone-imagerie attend S,N,O,E}"); shift ;;
    --itineraire) ITINERAIRE=1 ;;
    --signal) SIGNAL=1 ;;
    --recherche) RECHERCHE=1 ;;
    --copies) COPIES=${2:?--copies attend un dossier}; shift ;;
    --antenne) ANTENNE=${2:?--antenne attend LAT,LON}; shift ;;
    --recepteur-1090) RECEPTEUR_1090=${2:?--recepteur-1090 attend HOTE:PORT}; shift ;;
    --phonie) PHONIE=${2:?--phonie attend une adresse de flux}; shift ;;
    --sans-build) BUILD=0 ;;
    --sans-ia) IA=0 ;;
    --sans-relief) RELIEF=0 ;;
    -h | --help) sed -n '2,/^set -euo/p' "$0" | sed '$d; s/^# \{0,1\}//'; exit 0 ;;
    *) echo "Option inconnue : $1 (voir --help)" >&2; exit 2 ;;
  esac
  shift
done
# Défaut : le Tchad, quand aucune --zone n'est donnée.
if [ ${#ZONES[@]} -eq 0 ]; then ZONES=("7,23,13,23"); fi

BILAN=()
A_FAIRE=()
etape() { printf '\n== %s\n' "$*"; }
ok() { BILAN+=("  ✓ $*"); echo "  ✓ $*"; }
rate() { BILAN+=("  ✗ $*"); echo "  ✗ $*" >&2; }

# attendre <commande> <secondes> : réessaie la commande chaque seconde jusqu'au délai.
attendre() {
  local i
  for ((i = 0; i < $2; i++)); do
    if "$1"; then return 0; fi
    sleep 1
  done
  return 1
}

# regler CLE valeur : écrit ou remplace la ligne CLE= de poste.env (les autres lignes restent).
regler() {
  if [ ! -f "$POSTE_ENV" ]; then
    printf '# Réglages du poste AfriControl, lus au démarrage du serveur.\n# Écrit par scripts/poste/preparer-poste ; une variable posée au lancement garde la main.\n' >"$POSTE_ENV"
    chmod 600 "$POSTE_ENV"
  fi
  awk -v cle="$1" -v valeur="$2" '
    index($0, cle "=") == 1 { if (!fait) print cle "=" valeur; fait = 1; next }
    { print }
    END { if (!fait) print cle "=" valeur }
  ' "$POSTE_ENV" >"$POSTE_ENV.tmp"
  cat "$POSTE_ENV.tmp" >"$POSTE_ENV"
  rm -f "$POSTE_ENV.tmp"
}

# telecharger <fichier> <adresse>… : première adresse qui répond ; reprise d'un .part interrompu.
telecharger() {
  local fichier=$1 adresse
  shift
  for adresse in "$@"; do
    echo "  téléchargement : $adresse"
    if curl -fL --retry 3 --retry-delay 3 -C - -o "$fichier.part" "$adresse"; then
      mv "$fichier.part" "$fichier"
      return 0
    fi
  done
  return 1
}

docker_pret() { command -v docker >/dev/null && docker info >/dev/null 2>&1; }
# Une image déjà là n'est pas retéléchargée : relancer le script hors ligne reste possible.
image_presente() { docker image inspect "$1" >/dev/null 2>&1; }

# installer_paquet <nom> : par apt (Debian, Ubuntu) ou dnf (Fedora, RHEL). Sans question posée
# (debconf) : le paquet prend ses réglages par défaut, le script règle ensuite ce qu'il faut.
installer_paquet() {
  local sudo=""
  if [ "$(id -u)" != 0 ]; then sudo=sudo; fi
  if command -v apt-get >/dev/null; then
    local apt=(env DEBIAN_FRONTEND=noninteractive apt-get)
    $sudo "${apt[@]}" install -y "$1" || { $sudo "${apt[@]}" update && $sudo "${apt[@]}" install -y "$1"; }
  elif command -v dnf >/dev/null; then
    $sudo dnf install -y "$1"
  else
    return 1
  fi
}

etape "Node"
if ! command -v node >/dev/null; then
  echo "Node 22 ou plus est requis : https://nodejs.org/fr/download" >&2
  exit 1
fi
if [ "$(node -p 'process.versions.node.split(".")[0]')" -lt 22 ]; then
  echo "Node $(node -v) est trop ancien : 22 ou plus est requis (https://nodejs.org/fr/download)." >&2
  exit 1
fi
ok "Node $(node -v)"

if [ "$BUILD" = 1 ]; then
  etape "Serveur AfriControl (dépendances, build autonome)"
  if ! npm ci --no-audit --no-fund || ! NITRO_PRESET=node-server npm run build; then
    echo "Le build a échoué (messages ci-dessus). Coupure réseau : relancer le script. Autre erreur (npm ci, build) : la signaler avec ces messages." >&2
    exit 1
  fi
  ok "serveur construit : .output/server/index.mjs"
fi

ia_repond() { curl -fsS -m 3 http://127.0.0.1:11434/api/version >/dev/null 2>&1; }

if [ "$IA" = 1 ]; then
  etape "IA du poste (Ollama, sur cette machine)"
  if ! command -v ollama >/dev/null; then
    # L'installeur officiel exige zstd, absent de bien des installations neuves.
    if ! command -v zstd >/dev/null; then
      echo "  installation de zstd (l'installeur d'Ollama en a besoin)…"
      installer_paquet zstd || true
    fi
    echo "  installation d'Ollama (script officiel d'ollama.com)…"
    curl -fsSL https://ollama.com/install.sh | sh || true
  fi
  if command -v ollama >/dev/null && ! ia_repond; then
    if [ -d /run/systemd/system ]; then
      if [ "$(id -u)" = 0 ]; then systemctl start ollama || true; else sudo systemctl start ollama || true; fi
    fi
    if ! ia_repond; then
      mkdir -p data
      nohup ollama serve >>data/ollama.log 2>&1 &
      A_FAIRE+=("Ollama n'a pas de service système ici : relancer « ollama serve » après un redémarrage.")
    fi
  fi
  if ! command -v ollama >/dev/null; then
    rate "IA : Ollama n'a pas pu être installé (messages ci-dessus)"
  elif ! attendre ia_repond 60; then
    rate "IA : Ollama ne répond pas sur 127.0.0.1:11434 (voir data/ollama.log)"
  else
    if [ -z "$MODELE" ]; then
      memoire=$(awk '/^MemTotal:/ { printf "%d", $2 / 1048576 + 0.5 }' /proc/meminfo)
      if [ "$memoire" -ge 15 ]; then
        MODELE=qwen2.5:7b
      elif [ "$memoire" -ge 7 ]; then
        MODELE=qwen2.5:3b
      else
        MODELE=qwen2.5:1.5b
      fi
      echo "  mémoire : $memoire Go → modèle $MODELE"
    fi
    if ! ollama pull "$MODELE"; then
      rate "IA : le modèle $MODELE n'a pas pu être téléchargé — relancer le script pour reprendre"
    else
      regler AFRICONTROL_IA http://127.0.0.1:11434/v1
      regler AFRICONTROL_IA_MODELE "$MODELE"
      echo "  essai d'une réponse (le premier chargement du modèle peut prendre une minute)…"
      debut=$(date +%s)
      if reponse=$(curl -fsS -m 300 http://127.0.0.1:11434/v1/chat/completions \
        -H 'Content-Type: application/json' \
        -d "{\"model\":\"$MODELE\",\"max_tokens\":12,\"messages\":[{\"role\":\"user\",\"content\":\"Réponds seulement : prêt.\"}]}"); then
        texte=$(printf '%s' "$reponse" | node -e 'let s="";process.stdin.on("data",(d)=>(s+=d)).on("end",()=>console.log(JSON.parse(s).choices[0].message.content.trim()))')
        ok "IA : $MODELE répond en $(($(date +%s) - debut)) s (« $texte »)"
      else
        rate "IA : $MODELE installé mais n'a pas répondu à l'essai (voir data/ollama.log)"
      fi
    fi
  fi
fi

if [ "$RELIEF" = 1 ]; then
  etape "Relief (tuiles Copernicus GLO-90, lues par le poste lui-même)"
  # Liste dédupliquée des tuiles couvrant TOUTES les zones demandées (n'importe quels continents) :
  # deux zones qui se chevauchent ne téléchargent pas deux fois le même degré carré.
  declare -A a_prendre=()
  for zone in "${ZONES[@]}"; do
    IFS=, read -r sud nord ouest est <<<"$zone"
    for v in "$sud" "$nord" "$ouest" "$est"; do
      if ! [[ "$v" =~ ^-?[0-9]+$ ]]; then
        echo "--zone attend quatre degrés entiers S,N,O,E (reçu : $zone)" >&2
        exit 2
      fi
    done
    if [ "$sud" -gt "$nord" ] || [ "$ouest" -gt "$est" ]; then
      echo "--zone : S≤N et O≤E attendus (reçu : $zone)" >&2
      exit 2
    fi
    for lat in $(seq "$sud" "$nord"); do
      for lon in $(seq "$ouest" "$est"); do
        ns=N ew=E
        if [ "$lat" -lt 0 ]; then ns=S; fi
        if [ "$lon" -lt 0 ]; then ew=W; fi
        a_prendre["$(printf 'Copernicus_DSM_COG_30_%s%02d_00_%s%03d_00_DEM' "$ns" "${lat#-}" "$ew" "${lon#-}")"]=1
      done
    done
  done
  mkdir -p data/relief
  total=${#a_prendre[@]}
  # Garde-fou : un continent entier, c'est des milliers de tuiles et des dizaines de Go, des heures
  # de téléchargement. On prévient et on laisse 5 s pour arrêter (Ctrl+C) avant de se lancer.
  if [ "$total" -gt 2000 ]; then
    echo "  ATTENTION : $total tuiles demandées (environ $((total * 45 / 10000)) Go). Ctrl+C pour arrêter ; sinon ça continue dans 5 s…"
    sleep 5
  fi
  n=0 neuves=0 mer=0 echecs=0
  for nom in "${!a_prendre[@]}"; do
    n=$((n + 1))
    fichier=data/relief/$nom.tif
    if [ -f "$fichier" ]; then continue; fi
    printf '\r  tuile %d/%d ' "$n" "$total"
    code=$(curl -sL --retry 3 --retry-delay 3 -m 600 -o "$fichier.part" -w '%{http_code}' \
      "https://copernicus-dem-90m.s3.amazonaws.com/$nom/$nom.tif" 2>/dev/null) || true
    # Une vraie tuile commence par l'en-tête TIFF « II » ; un portail captif renverrait du HTML.
    if [ "$code" = 200 ] && [ "$(head -c 2 "$fichier.part")" = II ]; then
      mv "$fichier.part" "$fichier"
      neuves=$((neuves + 1))
    elif [ "$code" = 404 ]; then
      rm -f "$fichier.part" # pas de tuile : la mer
      mer=$((mer + 1))
    else
      rm -f "$fichier.part"
      echecs=$((echecs + 1))
    fi
  done
  echo
  presentes=$(find data/relief -maxdepth 1 -name 'Copernicus_DSM_COG_*_DEM.tif' | wc -l)
  ok "relief : $presentes tuiles dans data/relief ($(du -sh data/relief | cut -f1)), dont $neuves téléchargées maintenant ; $mer en mer, sans tuile"
  if [ "$echecs" -gt 0 ]; then
    rate "relief : $echecs tuiles n'ont pas pu être téléchargées — relancer le script pour les reprendre"
  fi
fi

if [ "$IMAGERIE" = 1 ]; then
  etape "Imagerie hors ligne (mosaïque Sentinel-2, compte Copernicus de l'opérateur)"
  # Le script de mosaïque fait tout (plan, garde-fous, reprise) : il lit poste.env ici même.
  args=()
  for zone in ${ZONES_IMAGERIE[@]+"${ZONES_IMAGERIE[@]}"}; do args+=(--zone "$zone"); done
  if node scripts/poste/imagerie-poste.mjs ${args[@]+"${args[@]}"}; then code=0; else code=$?; fi
  if [ "$code" = 0 ]; then
    plan=$(node scripts/poste/imagerie-poste.mjs ${args[@]+"${args[@]}"} --essai | sed -n 's/^  zooms /zooms /p')
    ok "imagerie : $plan — lues par le serveur, même hors ligne"
  elif [ "$code" = 1 ]; then
    rate "imagerie : des tuiles n'ont pas pu être obtenues — relancer le script pour les reprendre"
  else
    rate "imagerie : arrêtée (raison ci-dessus)"
  fi
  if [ -z "${AFRICONTROL_SENTINEL_ID:-}" ] && ! grep -qs '^AFRICONTROL_SENTINEL_ID=' "$POSTE_ENV"; then
    A_FAIRE+=(
      "Imagerie hors ligne : créer un client OAuth sur le compte Copernicus (gratuit) :"
      "  https://shapps.dataspace.copernicus.eu/dashboard/#/account/settings → User Settings → OAuth clients → Create ;"
      "  l'écrire dans poste.env : AFRICONTROL_SENTINEL_ID=… et AFRICONTROL_SENTINEL_SECRET=…"
      "  (le même compte sert à l'imagerie fraîche de la console), puis relancer avec --imagerie."
    )
  fi
fi

osrm_repond() {
  curl -fsS -m 5 'http://127.0.0.1:5810/route/v1/driving/15.0444,12.1067;20.8324,13.8292?overview=false' 2>/dev/null | grep -q '"code":"Ok"'
}

if [ "$ITINERAIRE" = 1 ]; then
  etape "Itinéraire (serveur OSRM du poste, carte OpenStreetMap du Tchad)"
  if ! docker_pret; then
    rate "itinéraire : Docker absent ou arrêté (https://docs.docker.com/engine/install/)"
  else
    mkdir -p data/osrm
    if [ -f data/osrm/tchad.osm.pbf ] || telecharger data/osrm/tchad.osm.pbf \
      https://download.openstreetmap.fr/extracts/africa/chad.osm.pbf \
      https://download.geofabrik.de/africa/chad-latest.osm.pbf; then
      if ! image_presente "$OSRM_IMAGE" && ! docker pull -q "$OSRM_IMAGE" >/dev/null; then
        rate "itinéraire : l'image $OSRM_IMAGE n'a pas pu être téléchargée — relancer le script"
      elif [ ! -f data/osrm/tchad.osrm.mldgr ]; then
        echo "  préparation du graphe routier (quelques minutes)…"
        for outil in "osrm-extract -p /opt/car.lua /data/tchad.osm.pbf" "osrm-partition /data/tchad.osrm" "osrm-customize /data/tchad.osrm"; do
          # shellcheck disable=SC2086 # l'outil et ses arguments, découpés exprès
          docker run --rm -v "$RACINE/data/osrm:/data" "$OSRM_IMAGE" $outil >data/osrm/preparation.log 2>&1 ||
            { rate "itinéraire : ${outil%% *} a échoué (voir data/osrm/preparation.log)"; break; }
        done
      fi
      if [ -f data/osrm/tchad.osrm.mldgr ]; then
        docker rm -f africontrol-osrm >/dev/null 2>&1 || true
        docker run -d --name africontrol-osrm --restart unless-stopped -p 127.0.0.1:5810:5000 \
          -v "$RACINE/data/osrm:/data" "$OSRM_IMAGE" osrm-routed --algorithm mld /data/tchad.osrm >/dev/null
        if attendre osrm_repond 120; then
          regler AFRICONTROL_ITINERAIRE http://127.0.0.1:5810
          km=$(curl -fsS 'http://127.0.0.1:5810/route/v1/driving/15.0444,12.1067;20.8324,13.8292?overview=false' |
            node -e 'let s="";process.stdin.on("data",(d)=>(s+=d)).on("end",()=>console.log(Math.round(JSON.parse(s).routes[0].distance/1000)))')
          ok "itinéraire : OSRM sur 127.0.0.1:5810, redémarre avec la machine (essai N'Djamena → Abéché : $km km par la route)"
        else
          rate "itinéraire : OSRM ne répond pas sur 127.0.0.1:5810 (docker logs africontrol-osrm)"
        fi
      fi
    else
      rate "itinéraire : la carte OSM du Tchad n'a pas pu être téléchargée — relancer le script"
    fi
  fi
fi

signal_repond() { curl -fsS -m 3 http://127.0.0.1:8085/v1/about >/dev/null 2>&1; }

if [ "$SIGNAL" = 1 ]; then
  etape "Relais Signal du poste (détail des alertes, chiffré jusqu'aux téléphones)"
  if ! docker_pret; then
    rate "relais Signal : Docker absent ou arrêté (https://docs.docker.com/engine/install/)"
  else
    mkdir -p data/signal
    # Docker Hub limite les téléchargements anonymes : le miroir de Google sert la même image.
    if ! image_presente "$SIGNAL_IMAGE" && ! docker pull -q "$SIGNAL_IMAGE" >/dev/null 2>&1 &&
      ! { docker pull -q "mirror.gcr.io/$SIGNAL_IMAGE" >/dev/null && docker tag "mirror.gcr.io/$SIGNAL_IMAGE" "$SIGNAL_IMAGE"; }; then
      rate "relais Signal : l'image $SIGNAL_IMAGE n'a pas pu être téléchargée — relancer le script"
    else
      docker rm -f africontrol-signal >/dev/null 2>&1 || true
      docker run -d --name africontrol-signal --restart unless-stopped -p 127.0.0.1:8085:8080 -e MODE=native \
        -v "$RACINE/data/signal:/home/.local/share/signal-cli" "$SIGNAL_IMAGE" >/dev/null
    fi
    if docker inspect africontrol-signal >/dev/null 2>&1 && attendre signal_repond 90; then
      ok "relais Signal sur 127.0.0.1:8085, redémarre avec la machine — reste à inscrire le numéro du poste (ci-dessous)"
      A_FAIRE+=(
        "Inscrire le numéro propre du poste chez Signal (une fois, sans relier de téléphone) :"
        "  1. une puce active réservée au poste, dans un mobile sans Signal pour ce numéro ;"
        "  2. AfriControl → Capteurs › Outils › Bot Signal du poste → Numéro propre au bot (chef de division) :"
        "     captcha de https://signalcaptchas.org/registration/generate, puis le code reçu par SMS ;"
        "  3. AfriControl → Division → Webhook Signal, coller (number = ce numéro, recipients = qui reçoit) :"
        "     http://127.0.0.1:8085/v2/send?number=+235XXXXXXXX&recipients=+235YYYYYYYY,+235ZZZZZZZZ"
        "  4. bot Signal (facultatif) : au même endroit, ajouter puis activer les numéros autorisés, et le bot."
      )
    else
      rate "relais Signal : ne répond pas sur 127.0.0.1:8085 (docker logs africontrol-signal)"
    fi
  fi
fi

# Le moteur répond, et en JSON (sans « json » dans search.formats, il répond 403).
recherche_repond() {
  curl -fsS -m 15 'http://127.0.0.1:8888/search?q=test&format=json' 2>/dev/null | grep -q '"results"'
}

if [ "$RECHERCHE" = 1 ]; then
  etape "Moteur de recherche du poste (SearXNG, pour /recherche)"
  if ! docker_pret; then
    rate "recherche : Docker absent ou arrêté (https://docs.docker.com/engine/install/)"
  else
    mkdir -p data/searxng
    # Écrit une fois : relancer le script garde la clé du moteur.
    if [ ! -f data/searxng/settings.yml ]; then
      cat >data/searxng/settings.yml <<FIN
# Moteur de recherche du poste AfriControl (scripts/poste/preparer-poste --recherche).
use_default_settings: true
server:
  secret_key: "$(od -An -tx1 -N32 /dev/urandom | tr -d ' \n')"
  limiter: false
search:
  formats:
    - html
    - json
FIN
    fi
    if ! image_presente "$SEARXNG_IMAGE" && ! docker pull -q "$SEARXNG_IMAGE" >/dev/null 2>&1 &&
      ! { docker pull -q "mirror.gcr.io/$SEARXNG_IMAGE" >/dev/null && docker tag "mirror.gcr.io/$SEARXNG_IMAGE" "$SEARXNG_IMAGE"; }; then
      rate "recherche : l'image $SEARXNG_IMAGE n'a pas pu être téléchargée — relancer le script"
    else
      docker rm -f africontrol-recherche >/dev/null 2>&1 || true
      # L'image écoute en IPv6 par défaut (::) : sur un noyau sans IPv6, elle plante en boucle
      # (erreur 97, vu à l'essai). IPv4 dans le conteneur ; le port reste lié au seul poste.
      docker run -d --name africontrol-recherche --restart unless-stopped -p 127.0.0.1:8888:8080 \
        -e GRANIAN_HOST=0.0.0.0 -v "$RACINE/data/searxng:/etc/searxng" "$SEARXNG_IMAGE" >/dev/null
    fi
    if docker inspect africontrol-recherche >/dev/null 2>&1 && attendre recherche_repond 90; then
      regler AFRICONTROL_RECHERCHE "http://127.0.0.1:8888"
      ok "moteur de recherche sur 127.0.0.1:8888, redémarre avec la machine — /recherche reste désactivée"
      A_FAIRE+=(
        "Recherche en ligne : le chef de division active /recherche (Capteurs › Outils › Commandes du poste)."
        "  La requête sort alors du poste ; jamais un contact du relevé ni des coordonnées ; journalisée."
      )
    else
      rate "recherche : le moteur ne répond pas en JSON sur 127.0.0.1:8888 (docker logs africontrol-recherche)"
    fi
  fi
fi

# Antenne 1090 MHz : le récepteur (dump1090) sur la clé radio, ses trames brutes lues par le poste.
recepteur_repond() { timeout 3 bash -c "exec 3<>/dev/tcp/${RECEPTEUR_1090%:*}/${RECEPTEUR_1090##*:}" 2>/dev/null; }

# trames_1090 : les trames brutes (AVR « *…; ») que sert le récepteur — 20 au plus, en 30 s au plus.
# Un port ouvert ne prouve pas qu'une antenne entend : ces trames, si.
trames_1090() {
  { timeout 30 bash -c "exec 3<>/dev/tcp/${RECEPTEUR_1090%:*}/${RECEPTEUR_1090##*:} && cat <&3" 2>/dev/null |
    grep -m 20 -aE '^\*[0-9A-Fa-f]+;' | wc -l; } || true
}

# cle_rtl_sdr [DOSSIER] : une clé radio RTL2832U branchée (0bda:2832 ou 0bda:2838), lue dans /sys —
# lsusb manque sur bien des postes, et l'aurait dite absente.
cle_rtl_sdr() {
  local d
  for d in "${1:-/sys/bus/usb/devices}"/*; do
    [ "$(cat "$d/idVendor" 2>/dev/null)" = 0bda ] || continue
    case "$(cat "$d/idProduct" 2>/dev/null)" in 2832 | 2838) return 0 ;; esac
  done
  return 1
}

if [ -n "$ANTENNE$RECEPTEUR_1090" ]; then
  etape "Antenne 1090 MHz du poste (réception seule)"
  if ! [[ "$ANTENNE" =~ ^(-?[0-9]{1,2}(\.[0-9]+)?),(-?[0-9]{1,3}(\.[0-9]+)?)$ ]] ||
    ! awk -v a="${BASH_REMATCH[1]}" -v o="${BASH_REMATCH[3]}" 'BEGIN { exit !(a >= -90 && a <= 90 && o >= -180 && o <= 180) }'; then
    rate "antenne 1090 : --antenne LAT,LON attendu, sa position en degrés décimaux (ex. 12.1331,15.0339)"
  else
    LAT=${BASH_REMATCH[1]}
    LON=${BASH_REMATCH[3]}
    LOCALE=""
    if [ -z "$RECEPTEUR_1090" ]; then
      RECEPTEUR_1090=127.0.0.1:30002
      LOCALE=1
      SUDO=""
      if [ "$(id -u)" != 0 ]; then SUDO=sudo; fi
      if ! command -v dump1090-mutability >/dev/null; then installer_paquet dump1090-mutability || true; fi
      if [ -f /etc/default/dump1090-mutability ]; then
        # La clé radio libérée de son pilote de télévision (DVB-T), qui la prendrait avant dump1090.
        printf 'blacklist dvb_usb_rtl28xxu\nblacklist rtl2832\nblacklist rtl2830\n' |
          $SUDO tee /etc/modprobe.d/africontrol-rtl-sdr.conf >/dev/null
        $SUDO modprobe -r dvb_usb_rtl28xxu 2>/dev/null || true
        $SUDO usermod -aG plugdev dump1090 2>/dev/null || true
        # Sa position, ses trames brutes sur 127.0.0.1:30002 seulement, lancé avec la machine.
        $SUDO sed -i -e "s/^LAT=.*/LAT=\"$LAT\"/" -e "s/^LON=.*/LON=\"$LON\"/" \
          -e 's/^START_DUMP1090=.*/START_DUMP1090="yes"/' \
          -e 's/^RAW_OUTPUT_PORT=.*/RAW_OUTPUT_PORT="30002"/' \
          -e 's/^NET_BIND_ADDRESS=.*/NET_BIND_ADDRESS="127.0.0.1"/' /etc/default/dump1090-mutability
        $SUDO systemctl enable dump1090-mutability >/dev/null 2>&1 || true
        # Sans systemd (conteneur, installation minimale) : par son script de démarrage.
        $SUDO systemctl restart dump1090-mutability >/dev/null 2>&1 ||
          $SUDO service dump1090-mutability restart >/dev/null 2>&1 || true
      else
        rate "antenne 1090 : le récepteur dump1090-mutability n'a pas pu être installé — en installer un (readsb, dump1090-fa), puis relancer avec --recepteur-1090 127.0.0.1:30002"
      fi
    fi
    regler AFRICONTROL_1090 "$RECEPTEUR_1090"
    regler AFRICONTROL_ANTENNE "$LAT,$LON"
    trames=0
    if attendre recepteur_repond 20; then
      debut=$SECONDS
      trames=$(trames_1090)
      duree=$((SECONDS - debut + 1))
    fi
    if [ "$trames" -gt 0 ]; then
      ok "antenne 1090 : $trames trame(s) brute(s) reçue(s) de $RECEPTEUR_1090 en moins de $duree s, antenne à $LAT,$LON — le poste les décode lui-même"
    elif [ -n "$LOCALE" ] && ! cle_rtl_sdr; then
      A_FAIRE+=("Antenne 1090 : aucune clé radio RTL-SDR vue — brancher la clé et son antenne, puis : sudo systemctl restart dump1090-mutability")
    elif recepteur_repond; then
      A_FAIRE+=("Antenne 1090 : $RECEPTEUR_1090 répond mais n'a servi aucune trame brute en 30 s — le port des trames brutes (30002 pour dump1090) ? antenne branchée, dégagée ? un aéronef à portée ? Le poste s'y raccroche seul.")
    else
      A_FAIRE+=("Antenne 1090 : rien n'écoute encore sur $RECEPTEUR_1090 — le poste s'y raccroche seul dès qu'il répond.")
    fi
  fi
fi

if [ -n "$PHONIE" ]; then
  etape "Phonie ATC (flux du récepteur VHF de l'opérateur, réception seule)"
  if ! [[ "$PHONIE" =~ ^https?://[^[:space:]]+$ ]]; then
    rate "phonie : --phonie attend une adresse http(s):// (sortie du récepteur VHF : rtl_airband, Icecast…)"
  else
    regler AFRICONTROL_ATC "$PHONIE"
    # Un flux sans fin : seul compte qu'il réponde (200) dans les 5 s.
    if [ "$(curl -s -m 5 -o /dev/null -w '%{http_code}' "$PHONIE" 2>/dev/null || true)" = 200 ]; then
      ok "phonie : flux $PHONIE — enregistré à la demande, doublé et scellé comme le reste"
    else
      A_FAIRE+=("Phonie ATC : $PHONIE ne répond pas encore — le poste réessaie seul quand l'enregistrement est demandé.")
    fi
  fi
fi

# disques_de CHEMIN : les disques physiques (sda, nvme0n1…) qui portent CHEMIN, un par ligne ;
# rien quand ils ne se lisent pas (dossier réseau, ZFS, conteneur…). Par le numéro du périphérique
# de son montage, lu dans /sys — pas par son nom : la racine se dit souvent « /dev/root », qui
# n'existe pas. Un montage sans périphérique propre (btrfs, « 0:… ») : celui de sa source.
disques_de() {
  local numero source periph
  numero=$(findmnt -no MAJ:MIN -T "$1" 2>/dev/null) || return 0
  periph=$(readlink -f "/sys/dev/block/$numero" 2>/dev/null) || periph=""
  if [ -z "$periph" ] || [ ! -e "$periph" ]; then
    source=$(findmnt -no SOURCE -T "$1" 2>/dev/null) || return 0
    [ -b "$source" ] || return 0
    periph=$(readlink -f "$source")
  fi
  lsblk -rsno NAME,TYPE "/dev/${periph##*/}" 2>/dev/null | awk '$2 == "disk" { print $1 }' | sort -u
}

# disque_interne DISQUES : chacun ni amovible ni sur USB (une clé, un disque USB s'en vont).
disque_interne() {
  local d amovible transport
  for d in $1; do
    read -r amovible transport < <(lsblk -dno RM,TRAN "/dev/$d" 2>/dev/null) || return 1
    if [ "$amovible" != 0 ] || [ "${transport:-}" = usb ]; then return 1; fi
  done
}

# autre_disque : un AUTRE disque interne que celui du poste pour ses copies — un système de
# fichiers Linux monté en écriture, hors des points du système, 10 Go libres au moins ; le plus de
# place. Écrit « Ko-libres point-de-montage », ou rien.
autre_disque() {
  local poste point fs options d libre meilleur="" max=0
  poste=$(disques_de data)
  [ -n "$poste" ] || return 0
  while read -r point fs options; do
    point=$(printf '%b' "$point") # findmnt -r écrit les espaces \x20
    case "$fs" in ext2 | ext3 | ext4 | xfs | btrfs | f2fs) ;; *) continue ;; esac
    case ",$options," in *,ro,*) continue ;; esac
    case "$point" in
      / | /boot | /boot/* | /efi | /usr | /usr/* | /var | /var/* | /tmp | /tmp/* | /snap/* | /media/* | /run/*) continue ;;
    esac
    d=$(disques_de "$point")
    if [ -z "$d" ] || [ -n "$(comm -12 <(echo "$poste") <(echo "$d"))" ] || ! disque_interne "$d"; then
      continue
    fi
    libre=$(df -Pk "$point" | awk 'NR == 2 { print $4 }')
    if [ "${libre:-0}" -ge 10485760 ] && [ "$libre" -gt "$max" ]; then
      meilleur=$point
      max=$libre
    fi
  done < <(findmnt -rno TARGET,FSTYPE,OPTIONS 2>/dev/null)
  if [ -n "$meilleur" ]; then echo "$max $meilleur"; fi
}

# creer_copies DOSSIER : créé par l'opérateur ; sous un point de montage à root (un disque monté
# par le système), créé par sudo puis rendu à l'opérateur qui lance le poste (lui seul l'écrit, 700).
# Choisi seul, réglé par --copies ou déjà dans poste.env mais disparu (disque remplacé) : pareil.
creer_copies() {
  mkdir -p "$1" 2>/dev/null && return 0
  sudo mkdir -p "$1" && sudo chown "$(id -u):$(id -g)" "$1" && sudo chmod 700 "$1" || return 1
  ok "dossier des copies créé par sudo sur $(findmnt -no TARGET -T "$1") (à root), rendu à $(id -un) seul"
}

etape "Copies du poste (un autre disque que le sien)"
# Le dossier du poste d'abord : sur une installation neuve sans IA ni relief, data/ n'existe pas
# encore, et son disque ne se lirait pas — aucun autre disque ne serait choisi.
mkdir -p data
REGLEES=""
if [ -f "$POSTE_ENV" ]; then REGLEES=$(sed -n 's/^AFRICONTROL_COPIES=//p' "$POSTE_ENV" | tail -n 1); fi
CHOISI=""
if [ -z "$COPIES" ] && [ -z "$REGLEES" ]; then
  read -r LIBRE POINT <<<"$(autre_disque)" || true
  if [ -n "${POINT:-}" ]; then
    # sudo refusé : dit, et les copies restent sur le disque du poste.
    if creer_copies "$POINT/AfriControl-copies"; then
      COPIES="$POINT/AfriControl-copies"
      CHOISI="$((LIBRE / 1048576)) Go libres"
    else
      A_FAIRE+=("Le disque choisi pour les copies ($POINT) appartient à root et sudo a refusé : sudo mkdir -p $POINT/AfriControl-copies && sudo chown $(id -un) $POINT/AfriControl-copies, puis relancer le script.")
    fi
  fi
fi
DOSSIER_COPIES=${COPIES:-${REGLEES:-data/copies}}
if ! creer_copies "$DOSSIER_COPIES"; then
  rate "copies : $DOSSIER_COPIES impossible à créer, même par sudo"
elif [ ! -w "$DOSSIER_COPIES" ]; then
  rate "copies : $DOSSIER_COPIES en lecture seule — le poste ne pourrait rien y doubler"
else
  DOSSIER_COPIES=$(cd "$DOSSIER_COPIES" && pwd -P)
  if [ -n "$COPIES" ]; then
    regler AFRICONTROL_COPIES "$DOSSIER_COPIES"
    if [ -n "$CHOISI" ]; then
      ok "copies du poste sur un autre disque interne, choisi seul : $DOSSIER_COPIES ($CHOISI)"
    else
      ok "copies du poste dans $DOSSIER_COPIES"
    fi
    if [ -n "$(ls -A data/copies 2>/dev/null)" ] && [ "$DOSSIER_COPIES" != "$(cd data/copies && pwd -P)" ]; then
      A_FAIRE+=("Les copies déjà faites dans data/copies : le poste les rapatrie dans $DOSSIER_COPIES (comparées une à une, puis retirées du disque du poste), et y recopie tout ce qu'il garde.")
    fi
  elif [ -n "$REGLEES" ]; then
    ok "copies du poste : AFRICONTROL_COPIES déjà réglé dans poste.env ($DOSSIER_COPIES), gardé"
  else
    ok "copies du poste dans data/copies (défaut)"
  fi
  DISQUES_POSTE=$(disques_de data)
  DISQUES_COPIES=$(disques_de "$DOSSIER_COPIES")
  if [ -z "$DISQUES_POSTE" ] || [ -z "$DISQUES_COPIES" ]; then
    A_FAIRE+=("Copies du poste : le disque de $DOSSIER_COPIES n'a pas pu être comparé à celui du poste — s'assurer qu'il est autre.")
  elif [ -n "$(comm -12 <(echo "$DISQUES_POSTE") <(echo "$DISQUES_COPIES"))" ]; then
    A_FAIRE+=("Copies du poste sur le même disque que lui (${DISQUES_POSTE//$'\n'/ }) : sa panne emporterait les deux. Brancher un autre disque, puis relancer avec --copies /chemin/sur/ce/disque.")
  else
    ok "copies sur un autre disque (${DISQUES_COPIES//$'\n'/ }) que le poste (${DISQUES_POSTE//$'\n'/ })"
  fi
fi

for ancienne in AFRICONTROL_DEEPSEEK XAI_API_KEY; do
  if [ -n "${!ancienne:-}" ] || grep -qs "^$ancienne=" "$POSTE_ENV"; then
    A_FAIRE+=("$ancienne n'est plus lue (l'IA reste sur le poste) : la retirer de l'environnement ou de poste.env.")
  fi
done

etape "Bilan"
printf '%s\n' "${BILAN[@]}"
if [ -f "$POSTE_ENV" ]; then
  echo
  echo "  poste.env :"
  grep '^AFRICONTROL_' "$POSTE_ENV" | sed 's/^/    /'
fi
if [ ${#A_FAIRE[@]} -gt 0 ]; then
  echo
  printf '  %s\n' "${A_FAIRE[@]}"
fi
echo
echo "  Lancer le poste (poste.env est lu tout seul) :"
echo "    PORT=8080 node .output/server/index.mjs"
echo "  Puis Capteurs > Outils > « Tester le serveur » pour l'IA, et le diagnostic pour le reste."
echo "  Relevé Internet : coupé à la livraison, rien ne sort du poste — le chef de division l'active"
echo "  dans Capteurs > Outils > Relevé Internet du poste."
for ligne in "${BILAN[@]}"; do
  if [[ "$ligne" == *✗* ]]; then exit 1; fi
done
